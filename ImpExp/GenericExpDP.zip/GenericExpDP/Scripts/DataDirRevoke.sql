-- Revokes privileges on data output directory
DROP DIRECTORY &1;
EXIT;

