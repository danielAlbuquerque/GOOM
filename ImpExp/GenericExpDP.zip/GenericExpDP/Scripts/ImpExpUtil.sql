---- ----------------------------------------------------------------------------------------
-- Intergraph Corporation - Security, Government, & Infrastructure
-- Huntsville, Alabama 35894
-- 
-- Chuck Woodbury - Senior Application Consultant.
-- cewoodbu@ingr.com
-- ----------------------------------------------------------------------------------------
-- Import/Export Utility for use with ImportOOM and ExportOOM batch files.
-- THis file must reside in the same directory as ImportOOM and ExportOOM.
--
set verify off
set serveroutput on
DECLARE
v_type   VARCHAR2(2):=UPPER('&1');
BEGIN
IF v_type='I' THEN
 GDOBKP.RestoreGDOSYSmetadata;
 GOOM.SpatialIndexAll;
 GDOBKP.DeleteBackupTables;
 EXECUTE IMMEDIATE 'PURGE RECYCLEBIN';
ELSIF v_type='E' THEN
 EXECUTE IMMEDIATE 'PURGE RECYCLEBIN';
 GDOBKP.SaveGDOSYSmetadata;
ELSE
 GOOM.DBMSG('Invalid Option given:'||v_type);
END IF;
END;
/
exit;