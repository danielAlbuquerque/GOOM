-- ----------------------------------------------------------------------------------------
-- Intergraph Corporation - Security, Government, & Infrastructure
-- Huntsville, Alabama 35894
-- 
-- Chuck Woodbury - Senior Consultant, Technical Services.
-- Chuck.Woodbury@intergraph.com
-- ----------------------------------------------------------------------------------------
-- Note:  GOOM Package must be installed before using this script.
-- ----------------------------------------------------------------------------------------
BEGIN
  GOOM.SpatialIndexAll;
END;
/
exit;

