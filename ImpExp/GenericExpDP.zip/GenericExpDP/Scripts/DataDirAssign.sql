-- ----------------------------------------------------------------------------------------
-- Intergraph Corporation - Security, Government, & Infrastructure
-- Huntsville, Alabama 35894
-- 
-- Chuck Woodbury - Senior Application Consultant.
-- chuck.woodbury@intergraph.com
-- ----------------------------------------------------------------------------------------
-- Create the output data directory
CREATE DIRECTORY &1 AS '&2';
GRANT READ, WRITE ON DIRECTORY &1 to PUBLIC;
exit;
--
