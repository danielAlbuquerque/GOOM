-- ----------------------------------------------------------------------------------------
-- Intergraph Corporation - Security, Government, & Infrastructure
-- Huntsville, Alabama 35894
-- 
-- Chuck Woodbury - Senior Application Consultant.
-- chuck.woodbury@intergraph.com
-- ----------------------------------------------------------------------------------------
set verify off
set termout on
set serverout on
--
DECLARE
v_user    VARCHAR2(32) := UPPER('&1');
v_count   PLS_INTEGER;
BEGIN
    SELECT COUNT(*) INTO v_count FROM ALL_USERS WHERE USERNAME=v_user;
    IF v_count <> 0 THEN
      EXECUTE IMMEDIATE 'DROP USER '||v_user||'  CASCADE';
    END IF;
    DBMS_OUTPUT.PUT_LINE('User '||v_user||' has been dropped.');
  EXCEPTION
    WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Error message: '||sqlerrm);
END;
/
undefine 1
set verify on
-- ---------------------------------------------------------------
exit;
