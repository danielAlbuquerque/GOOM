-- ADDUSER
-- ----------------------------------------------------------------------------------------
-- Intergraph Corporation - Security, Government, & Infrastructure
-- Huntsville, Alabama 35894
-- 
-- Chuck Woodbury - Senior Application Consultant.
-- chuck.woodbury@intergraph.com
-- ----------------------------------------------------------------------------------------
-- Creates a new master schema for use with GeoMedia/GMPro
-- Syntax: @dbadduser <username>
-- The username and password will be the same.  Use the password command
-- to change the password after schema creation.
-- ---------------------------------------------------------------
set verify off
set termout on
set serverout on
DECLARE
c_proc              CONSTANT VARCHAR2(32) := 'DBADDUSER';
c_tabspace          CONSTANT VARCHAR2(30) := 'USERS';
c_tempspace         CONSTANT VARCHAR2(30) := 'TEMP';
--
v_user              VARCHAR2(32)          := UPPER('&1');
v_count             PLS_INTEGER;
BEGIN
    SELECT COUNT(*) INTO v_count FROM ALL_USERS WHERE USERNAME=v_user;
    IF v_count <> 0 THEN
      EXECUTE IMMEDIATE 'DROP USER '||v_user||'  CASCADE';
    END IF;
    EXECUTE IMMEDIATE 'CREATE USER '||v_user||' PROFILE "DEFAULT" IDENTIFIED BY '||v_user||' DEFAULT TABLESPACE '||c_tabspace||' TEMPORARY TABLESPACE '||c_tempspace||' ACCOUNT UNLOCK';
    -- You can assign a quota here but unlimited is generally easier to manager.
    EXECUTE IMMEDIATE 'GRANT UNLIMITED TABLESPACE TO '||v_user;
    -- These privs are required for a user that owns data.
    EXECUTE IMMEDIATE 'GRANT CONNECT TO '||v_user;
    EXECUTE IMMEDIATE 'GRANT RESOURCE TO '||v_user;
    EXECUTE IMMEDIATE 'GRANT CREATE TABLE TO '||v_user;
    EXECUTE IMMEDIATE 'GRANT CREATE VIEW TO '||v_user;
    EXECUTE IMMEDIATE 'GRANT CREATE SEQUENCE TO '||v_user;
    -- Merge any view is required for 10g or later
    EXECUTE IMMEDIATE 'GRANT MERGE ANY VIEW TO '||v_user;
    -- Create Mat View is optional, set for INGR testing.
    EXECUTE IMMEDIATE 'GRANT CREATE MATERIALIZED VIEW TO '||v_user;
    DBMS_OUTPUT.PUT_LINE('User '||v_user||' has been created.');
  EXCEPTION
    WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Error in:'||c_proc);
    DBMS_OUTPUT.PUT_LINE('Error message: '||sqlerrm);
END;
/
undefine 1
set verify on
-- ---------------------------------------------------------------
exit;
