-- ----------------------------------------------------------------------------------------
-- Intergraph Corporation - Security, Government, & Infrastructure
-- Huntsville, Alabama 35894
-- 
-- Chuck Woodbury - Senior Application Consultant.
-- chuck.woodbury@intergraph.com
-- ----------------------------------------------------------------------------------------
BEGIN
  GDOBKP.DeleteBackupTables;
  GOOM.Response('Clean Up','Post Export Clean up has been completed.');
END;
/
exit;